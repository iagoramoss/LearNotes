#  LearNotes

Hi, my name is Iago! 
I'm a person who is completely in love with music, and I decided to make my Playground about this passion.

This Playground explains about the origins of the musical notes as we know them today, with interactions to enhance the experience

For an even better experience, please run the project on iPhones 12 or 14 (Pro and Pro Max included)
